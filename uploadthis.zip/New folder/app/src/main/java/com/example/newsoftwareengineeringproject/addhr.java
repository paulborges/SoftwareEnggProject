package com.example.newsoftwareengineeringproject;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class addhr extends AppCompatActivity {
    EditText HRname;
    EditText HRid;
    EditText jobtype,hrpassword;
    String hrname,hrid,type,jobname,hrpass;
    Spinner jobs;
    Button addButton;
    DatabaseReference databaseHR;
    Toolbar mToolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addhr);

        databaseHR = FirebaseDatabase.getInstance().getReference("HR");

        HRname =  (EditText) findViewById(R.id.editText1);
        HRid =  (EditText) findViewById(R.id.editText3);
        jobtype =  (EditText) findViewById(R.id.editText4);
        jobs = (Spinner) findViewById(R.id.spinner3);
        hrpassword =  (EditText) findViewById(R.id.editText5);
        mToolbar=(Toolbar)findViewById(R.id.ftoolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Add/Remove HR");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



    }

    public void addHR(View v){
        hrname = HRname.getText().toString();
        hrid = HRid.getText().toString();
        type = jobtype.getText().toString();
        jobname = jobs.getSelectedItem().toString();
        hrpass = hrpassword.getText().toString();

        if (!(TextUtils.isEmpty(HRid.getText().toString()))) {
            // String id = databaseTeacher.push().getKey();
            HR hr =new HR(hrname ,hrid ,type ,jobname,hrpass);
            databaseHR.child(hrid).setValue(hr);
            Toast.makeText(getApplicationContext(),"HR added successfully", Toast.LENGTH_LONG).show();
            finish();

        }else {
            Toast.makeText(getApplicationContext(),"fields cannot be empty", Toast.LENGTH_LONG).show();
        }
    }
    public void removeHR(View v){
        if (!TextUtils.isEmpty(HRid.getText().toString())) {
            hrid = HRid.getText().toString();
            databaseHR.child(hrid).setValue(null);
            Toast.makeText(getApplicationContext(),"HR removed successfully", Toast.LENGTH_LONG).show();
            finish();

        }else {
            Toast.makeText(getApplicationContext(),"id cannot be empty", Toast.LENGTH_LONG).show();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
