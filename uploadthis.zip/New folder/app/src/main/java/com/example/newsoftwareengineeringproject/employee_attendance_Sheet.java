package com.example.newsoftwareengineeringproject;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class employee_attendance_Sheet extends AppCompatActivity {
    public static int TOC=1,NOP=1,NOA=1;
    float average= (float) 0.0;
    TextView t;
    String avg,h1,h2,h3,h4,h5,h6,h7,h8;
    String employee_id;
    ArrayList dates = new ArrayList<>();;
    DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
    DatabaseReference dbAttendance;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_attendance__sheet);

        t=(TextView) findViewById(R.id.textView3);

        listView = (ListView) findViewById(R.id.list);
        Bundle bundle = getIntent().getExtras();
        employee_id = bundle.getString("eid");
        t.setText(employee_id);

        dates.clear();
        dates.add("       Date          "+"h1  "+"h2  "+"h3  "+"h4   "+ "h5   "+"h6  "+"h7  "+"h8");

        dbAttendance = ref.child("attendance");
        dbAttendance.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot dsp : dataSnapshot.getChildren()) {
                    h1 = dsp.child(employee_id).child("h1").getValue().toString().substring(0, 1);
                    h2 = dsp.child(employee_id).child("h2").getValue().toString().substring(0, 1);
                    h3 = dsp.child(employee_id).child("h3").getValue().toString().substring(0, 1);
                    h4 = dsp.child(employee_id).child("h4").getValue().toString().substring(0, 1);
                    h5 = dsp.child(employee_id).child("h5").getValue().toString().substring(0, 1);
                    h6 = dsp.child(employee_id).child("h6").getValue().toString().substring(0, 1);
                    h7 = dsp.child(employee_id).child("h7").getValue().toString().substring(0, 1);
                    h8 = dsp.child(employee_id).child("h8").getValue().toString().substring(0, 1);
                    dates.add(dsp.getKey() + "    " + h1 + "     " + h2 + "     " + h3 + "     " + h4 + "      " + h5 + "       " + h6 + "      " + h7 + "      " + h8); //add result into array list


                    //  Toast.makeText(getApplicationContext(),dsp.child(student_id).child("p1").getValue().toString(),Toast.LENGTH_LONG).show();
                    if (h1.equals("P")||h2.equals("P")||h3.equals("P")||h4.equals("P")||h5.equals("P")||h6.equals("P")||h7.equals("P")||h8.equals("P")) {

                        NOP++;
                        TOC++;
                    }
                    if(h1.equals("A")||h2.equals("A")||h3.equals("A")||h4.equals("A")||h5.equals("A")||h6.equals("A")||h7.equals("A")||h8.equals("A")) {
                        NOA++;
                        TOC++;
                    }
                }
                list(dates,NOP,TOC,NOA);
                //  Toast.makeText(getApplicationContext(), dates.toString(), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "something went wrong", Toast.LENGTH_LONG).show();
            }
        });

    }
    public void list(ArrayList employeelist,int NOP,int TOC,int NOA){
        // Toast.makeText(this,NOP+TOC,Toast.LENGTH_LONG).show();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, employeelist);
        // Assign adapter to ListView
        listView.setAdapter(adapter);
        try {
            average =(float)((NOP*100)/TOC);
            String avg=Float.toString(average);
            t.setText("Your Attendance is :"+avg+"%");
            if(average>=75)
                t.setTextColor(Color.GREEN);
            if(average<75)
                t.setTextColor(Color.RED);
        }
        catch (Exception e){e.printStackTrace();}

    }

}
