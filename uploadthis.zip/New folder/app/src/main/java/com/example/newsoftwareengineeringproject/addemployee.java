package com.example.newsoftwareengineeringproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class addemployee extends AppCompatActivity {
    EditText Ename;
    EditText Eid,epassword;
    String ename,eid,jobname,epass;
    Spinner jobs;
    DatabaseReference databaseEmployee;
    Toolbar mToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addemployee);

        databaseEmployee = FirebaseDatabase.getInstance().getReference("Employee");

        Ename =  (EditText) findViewById(R.id.editText1);
        Eid =  (EditText) findViewById(R.id.editText3);
        jobs = (Spinner) findViewById(R.id.spinner3);
        epassword = (EditText) findViewById(R.id.editText4);
        mToolbar=(Toolbar)findViewById(R.id.ftoolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Add/Remove Employee");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


       /* addButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                addTeacher();
            }
        });*/
    }

    public void addEmployee(View v){


        if (!(TextUtils.isEmpty(Eid.getText().toString()))) {
            //String id = databaseStudent.push().getKey();
            ename = Ename.getText().toString();
            eid = Eid.getText().toString();
            jobname = jobs.getSelectedItem().toString();
            epass = epassword.getText().toString();

            Employee employee =new Employee(ename ,eid,jobname,epass );
            databaseEmployee.child(eid).setValue(employee);
            Toast.makeText(getApplicationContext(),"Employee added successfully", Toast.LENGTH_LONG).show();

        }else {
            Toast.makeText(getApplicationContext(),"fields cannot be empty", Toast.LENGTH_LONG).show();
        }
    }
    public void removeEmployee(View v){
        if (!TextUtils.isEmpty(Eid.getText().toString())) {
            eid = Eid.getText().toString();
            databaseEmployee.child(eid).setValue(null);
            Toast.makeText(getApplicationContext(),"Employee removed successfully", Toast.LENGTH_LONG).show();

        }else {
            Toast.makeText(getApplicationContext(),"id cannot be empty", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
