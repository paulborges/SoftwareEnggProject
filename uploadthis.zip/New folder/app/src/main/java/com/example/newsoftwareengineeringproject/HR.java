package com.example.newsoftwareengineeringproject;

public class HR {

    String hrname;
    String hrid;
    String jobtype;
    String job;
    String hrpass;

  /*  public Teacher(String tname, String tid, EditText subject, Spinner classes){

    }*/

    public HR(String hrname, String hrid, String jobtype, String job, String hrpass) {
        this.hrname = hrname;
        this.hrid = hrid;
        this.jobtype = jobtype;
        this.job = job;
        this.hrpass = hrpass;
    }

    public String getHRname() {
        return hrname;
    }

    public String getHRid() {
        return hrid;
    }

    public String getJobtype() {
        return jobtype;
    }

    public String getJob() {
        return job;
    }

    public String gethrpass() {
        return hrpass;
    }

}
