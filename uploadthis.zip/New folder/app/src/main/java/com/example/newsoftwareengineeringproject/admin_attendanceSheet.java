package com.example.newsoftwareengineeringproject;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class admin_attendanceSheet extends AppCompatActivity {

    ListView listView;
    Spinner class_name;
    String classes;
    EditText date;
    ArrayList Userlist = new ArrayList<>();
    ArrayList Employeelist = new ArrayList<>();

    DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
    DatabaseReference dbAttendance;
    DatabaseReference dbEmployee;
    String required_date;
    Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_attendance_sheet);
        mToolbar=(Toolbar)findViewById(R.id.ftoolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Attendance Records");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        listView = (ListView) findViewById(R.id.list);
        class_name = (Spinner) findViewById(R.id.spinner5);
        date = (EditText) findViewById(R.id.date);

        classes = class_name.getSelectedItem().toString();



    }

    public void display_list(final ArrayList userlist) {
        Employeelist.clear();
        required_date = date.getText().toString();
        dbAttendance = ref.child("attendance");
        dbAttendance.child(required_date).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Result will be holded Here

                Employeelist.add("      EID              "+"h1  "+"h2  "+"h3  "+"h4   "+ "h5   "+"h6  "+"h7  "+"h8");
                for (Object eid : userlist) {

                    //DataSnapshot dsp=dataSnapshot.child(sid.toString());
                    String h1=dataSnapshot.child(eid.toString()).child("h1").getValue().toString().substring(0,1);
                    String h2=dataSnapshot.child(eid.toString()).child("h2").getValue().toString().substring(0,1);
                    String h3=dataSnapshot.child(eid.toString()).child("h3").getValue().toString().substring(0,1);
                    String h4=dataSnapshot.child(eid.toString()).child("h4").getValue().toString().substring(0,1);
                    String h5=dataSnapshot.child(eid.toString()).child("h5").getValue().toString().substring(0,1);
                    String h6=dataSnapshot.child(eid.toString()).child("h6").getValue().toString().substring(0,1);
                    String h7=dataSnapshot.child(eid.toString()).child("h7").getValue().toString().substring(0,1);
                    String h8=dataSnapshot.child(eid.toString()).child("h8").getValue().toString().substring(0,1);
                    Employeelist.add(dataSnapshot.child(eid.toString()).getKey().toString()+"    "+ h1+"     "+h2+"     "+h3+"     "+h4+"      "+h5+"       "+h6+"      "+h7+"      "+h8); //add result into array list
                }
                //Toast.makeText(getApplicationContext(),Studentlist.toString(), Toast.LENGTH_LONG).show();
                list(Employeelist);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "something went wrong", Toast.LENGTH_LONG).show();
            }

        });




    }




    public void viewlist(View v){

        Userlist.clear();
        dbEmployee = ref.child("Student");
        dbEmployee.orderByChild("classes").equalTo(class_name.getSelectedItem().toString()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Result will be holded Here
                for (DataSnapshot dsp : dataSnapshot.getChildren()) {
                    Userlist.add(dsp.child("sid").getValue().toString()); //add result into array list
                }
                display_list(Userlist);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "something went wrong", Toast.LENGTH_LONG).show();
            }

        });




    }
    public void list(ArrayList studentlist){
        //int color = Color.argb(255, 255, 175, 64);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, studentlist);
        // Assign adapter to ListView
        listView.setAdapter(adapter);


    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


}
