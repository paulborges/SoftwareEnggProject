package com.example.newsoftwareengineeringproject;

public class Employee {
    String ename;
    String eid;
    String job;
    String epass;

  /*  public Student(String sname, String sid){

    }*/

    public Employee(String ename, String eid,String job,String epass) {
        this.ename = ename;
        this.eid = eid;
        this.job = job;
        this.epass = epass;
    }

    public String getEname() { return ename; }

    public String getEid() {
        return eid;
    }
    public String getJob() {
        return job;
    }

    public String getepass() { return epass; }
}
